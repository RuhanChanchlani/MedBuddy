const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const extractText = require("../services/extractText");
const aiService = require("../services/aiService");
const Prescription = require("../models/Prescription");
const auth = require("../middleware/authMiddleware");

const router = express.Router();

// Multer config — store in /uploads, accept PDF and images
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = ["application/pdf", "image/png", "image/jpeg", "image/jpg"];
  if (allowed.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Only PDF and image files are allowed"), false);
  }
};

const upload = multer({ storage, fileFilter, limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB

// POST /upload — upload and analyze prescription
router.post("/", auth, upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const text = await extractText(req.file.path);
    const result = await aiService(text);

    // Save to DB
    const prescription = await Prescription.create({
      userId: req.user.id,
      originalText: text,
      fileName: req.file.originalname,
      result,
    });

    // Clean up uploaded file after processing
    fs.unlink(req.file.path, () => {});

    res.json({ prescriptionId: prescription._id, ...result });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ error: "Processing failed. Please try again." });
  }
});

// GET /upload/history — fetch user's prescription history
router.get("/history", auth, async (req, res) => {
  try {
    const data = await Prescription.find({ userId: req.user.id })
      .sort({ createdAt: -1 })
      .select("-originalText"); // exclude raw text for lighter payload

    res.json(data);
  } catch (err) {
    console.error("History error:", err);
    res.status(500).json({ error: "Could not fetch history" });
  }
});

// GET /upload/history/:id — fetch a single prescription detail
router.get("/history/:id", auth, async (req, res) => {
  try {
    const prescription = await Prescription.findOne({
      _id: req.params.id,
      userId: req.user.id,
    });

    if (!prescription) {
      return res.status(404).json({ error: "Prescription not found" });
    }

    res.json(prescription);
  } catch (err) {
    console.error("Fetch prescription error:", err);
    res.status(500).json({ error: "Could not fetch prescription" });
  }
});

// DELETE /upload/history/:id — delete a prescription
router.delete("/history/:id", auth, async (req, res) => {
  try {
    const prescription = await Prescription.findOneAndDelete({
      _id: req.params.id,
      userId: req.user.id,
    });

    if (!prescription) {
      return res.status(404).json({ error: "Prescription not found" });
    }

    res.json({ message: "Deleted successfully" });
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).json({ error: "Could not delete prescription" });
  }
});

module.exports = router;
