# 🏥 Healthcare Hackathon — Backend

REST API for AI-powered prescription analysis. Built with Node.js, Express, MongoDB, and JWT auth.

---

## 📁 Folder Structure

```
backend/
├── config/
│   └── db.js                  # MongoDB connection
├── middleware/
│   └── authMiddleware.js      # JWT verification
├── models/
│   ├── User.js                # User schema
│   └── Prescription.js        # Prescription schema
├── routes/
│   ├── authRoutes.js          # Signup / Login
│   └── uploadRoutes.js        # File upload + history
├── services/
│   ├── extractText.js         # PDF text extraction
│   └── aiService.js           # AI analysis (mock/OpenAI)
├── uploads/                   # Temp file storage (git-ignored)
├── .env.example               # Environment variable template
├── .gitignore
├── package.json
└── server.js                  # Entry point
```

---

## ⚙️ Setup

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm run dev
```

---

## 🌐 API Reference

### Auth

| Method | Endpoint        | Body                        | Description     |
|--------|-----------------|-----------------------------|-----------------|
| POST   | `/auth/signup`  | `{ email, password }`       | Register user   |
| POST   | `/auth/login`   | `{ email, password }`       | Login → token   |

### Upload & History

All routes below require `Authorization: Bearer <token>` header.

| Method | Endpoint                  | Body / Params        | Description                    |
|--------|---------------------------|----------------------|--------------------------------|
| POST   | `/upload`                 | `form-data: file`    | Upload prescription, get result|
| GET    | `/upload/history`         | —                    | Get all user prescriptions     |
| GET    | `/upload/history/:id`     | `:id` param          | Get single prescription        |
| DELETE | `/upload/history/:id`     | `:id` param          | Delete a prescription          |

### Health Check

| Method | Endpoint    | Description        |
|--------|-------------|--------------------|
| GET    | `/health`   | Server status      |

---

## 🤖 Integrating OpenAI

1. `npm install openai`
2. Add `OPENAI_API_KEY=your_key` to `.env`
3. In `services/aiService.js`, uncomment the OpenAI section and export `aiServiceOpenAI`

---

## 📦 Environment Variables

```env
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_strong_secret_key
PORT=5000
```
