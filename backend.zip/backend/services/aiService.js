/**
 * AI Service — Analyzes prescription text and returns structured data.
 *
 * Currently returns mock data.
 * To integrate OpenAI, install the SDK:
 *   npm install openai
 * Then replace the mock below with the real call.
 */

// ──────────────────────────────────────────────
// MOCK RESPONSE (active by default)
// ──────────────────────────────────────────────
async function aiServiceMock(text) {
  // Simulate processing delay
  await new Promise((r) => setTimeout(r, 300));

  return {
    diagnosis: "Sample diagnosis extracted from prescription text",
    medications: [
      { name: "Paracetamol", dosage: "500mg", frequency: "Twice daily", duration: "5 days" },
      { name: "Amoxicillin", dosage: "250mg", frequency: "Three times daily", duration: "7 days" },
    ],
    side_effects: [
      "Nausea",
      "Dizziness",
      "Avoid alcohol while on antibiotics",
    ],
    checklist: [
      "Take medications with food",
      "Complete full course of antibiotics",
      "Drink at least 8 glasses of water daily",
      "Rest and avoid strenuous activity",
    ],
    warnings: [],
    rawTextLength: text.length,
  };
}

// ──────────────────────────────────────────────
// OPENAI INTEGRATION (uncomment when ready)
// ──────────────────────────────────────────────
/*
const OpenAI = require("openai");
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function aiServiceOpenAI(text) {
  const prompt = `
You are a medical assistant AI. Analyze the following prescription text and return a JSON object with these fields:
- diagnosis: string
- medications: array of { name, dosage, frequency, duration }
- side_effects: array of strings
- checklist: array of patient instructions
- warnings: array of strings (allergy alerts, drug interactions, etc.)

Prescription text:
"""
${text}
"""

Respond ONLY with valid JSON. No markdown, no explanation.
`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" },
  });

  const raw = response.choices[0].message.content;
  return JSON.parse(raw);
}
*/

// Export: swap to aiServiceOpenAI when integrating OpenAI
module.exports = aiServiceMock;
