const fs = require("fs");
const path = require("path");
const pdfParse = require("pdf-parse");

/**
 * Extracts text from an uploaded file.
 * Supports: PDF, plain text. Images return a placeholder.
 */
async function extractText(filePath) {
  const ext = path.extname(filePath).toLowerCase();

  try {
    if (ext === ".pdf") {
      const buffer = fs.readFileSync(filePath);
      const data = await pdfParse(buffer);
      return data.text || "No readable text found in PDF";
    }

    if (ext === ".txt") {
      return fs.readFileSync(filePath, "utf-8");
    }

    // For images (jpg, jpeg, png) — return placeholder
    // TODO: integrate an OCR service like Tesseract or Google Vision API
    return "Image uploaded — OCR not yet integrated. Please use a PDF or text file.";
  } catch (err) {
    console.error("Text extraction error:", err.message);
    return "Could not extract text from the uploaded file.";
  }
}

module.exports = extractText;
